package UI;



import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

import Core.Color;
import Core.Piece;
import Core.Player;

public class mainGui {
	public static void main(String[] args){

	DrawFrame frame = new DrawFrame();
	
//	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//	frame.add(mainBoard);
//	frame.pack();
	frame.show();
	}
	
	
}
